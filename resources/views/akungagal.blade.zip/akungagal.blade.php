<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> @vite('resources/css/app.css')
<link rel="stylesheets" href="">
<title>Akun Gagal</title>
</head>

<body>
    <div style="width: 100%; height: 100%; position: relative; background: white">
        <div
            style="left: 466px; top: 237px; position: absolute; color: #332317; font-size: 28px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
            Lengkapi Formulir</div>
        <div style="width: 350px; height: 75px; left: 466px; top: 299px; position: absolute">
            <div
                style="left: 0px; top: 0px; position: absolute; color: #332317; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Alamat Email</div>
            <input type="email" id="base-input"
                style="padding-left: 15px; width: 350px; height: 45px; left: 0px; top: 30px; position: absolute; background: #F3F3F3; border-radius: 8px"></input>
        </div>
        <div style="height: 75px; left: 466px; top: 390px; position: absolute">
            <div
                style="left: 0px; top: 0px; position: absolute; color: #332317; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Password</div>
            <input type="password" id="base-input"
                style=" padding-left: 15px; width: 350px; height: 45px; left: 0px; top: 30px; position: absolute; background: #F3F3F3; border-radius: 8px"></input>
        </div>
        <div style="width: 350px; height: 45px; left: 466px; top: 563px; position: absolute">
            <button class="bg-brown2-500 hover:bg-brown2-700 text-white font-bold py-2 px-20 h-12 w-full rounded ">
                Daftar Sekarang
            </button>
        </div>
        <div style="width: 350px; height: 45px; left: 466px; top: 624px; position: absolute">
            <button
                class="bg-transparent hover:bg-brown2-500 text-brown2-700 font-semibold hover:text-white py-2 px-4 h-12 w-full border border-brown2-500 hover:border-transparent rounded">
                Kembali Masuk
            </button>
        </div>
        <div style="width: 560px; height: 45px; left: 360px; top: 135px; position: absolute">
            <div
                style="width: 520px; height: 45px; left: 15px; top: px; position: absolute; background: #BB8760; border-radius: 8px">
            </div>
            <div
                style="left: 60px; top: 12px; position: absolute;  text-align: center; color: white; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Maaf, email anda sudah terdaftar pada sistem kami !</div>
        </div>
        <div style="width: 952px; height: 47px; left: 99px; top: 33px; position: absolute">
            <div style="width: 120px; height: 45px; left: 1033px; top: 0px; position: absolute">
                <button class="bg-brown2-500 hover:bg-brown2-700 text-white font-bold py-2 px-4 rounded">
                    Masuk
                </button>
            </div>

            <div
                style="left: 733px; top: 11px; position: absolute; text-align: right; color: #332317; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Beranda</div>
            <div
                style="left: 833px; top: 11px; position: absolute; text-align: right; color: #332317; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Provinsi</div>
            <div
                style="left: 933px; top: 11px; position: absolute; text-align: right; color: #332317; font-size: 16px; font-family: Poppins; font-weight: 400; word-wrap: break-word">
                Daftar</div>
            <div
                style="left: 0px; top: 0px; position: absolute; text-align: center; color: #4F0E0E; font-size: 30px; font-family: Jawa Palsu; font-weight: 400; letter-spacing: 1.50px; word-wrap: break-word">
                BudayaPedia</div>
        </div>
    </div>
</body>

</html>