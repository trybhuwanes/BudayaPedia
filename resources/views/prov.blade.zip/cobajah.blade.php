<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> @vite('resources/css/app.css')
    <link rel="stylesheets" href="">
    <title>cobajah</title>
</head>

<body>
    <div class="w-[700px] h-[1807px] relative bg-white">
        <div class="w-[750px] h-[431px] left-[100px] top-[125px] absolute">
            <!-- <div class="left-0 top-0 absolute text-stone-800 text-xl font-medium font-['Poppins']">Semua Provinsi</div> -->
            <div class="w-[216px] h-[179px] left-0 top-[46px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-0 absolute" src="{{ URL('assets/img/jatim.jpg')}}" />
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Jawa Timur
                </div>
            </div>
            <div class="w-[216px] h-[179px] left-0 top-[252px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-[-0px] absolute"
                        src="{{ URL('assets/img/jatim.jpg')}}"  /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}"  />
                    </div>
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Madura
                </div>
            </div>
            <div class="w-[216px] h-[178px] left-[241px] top-[47px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" /> -->
                    </div>
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-[4px] top-[151px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Jawa
                    Tengah</div>
            </div>
            <div class="w-[216px] h-[179px] left-[245px] top-[252px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <!-- <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                        src="https://via.placeholder.com/220x236" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" />
                        </div>
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">D.I
                    Yogyakarta</div>
            </div>
            <div class="w-[216px] h-[179px] left-[490px] top-[46px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[216px] left-0 top-0 absolute" src="https://via.placeholder.com/216x216" />
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div> -->
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Jawa Barat
                </div>
            </div>
            <div class="w-[216px] h-[179px] left-[490px] top-[252px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[218px] h-[205px] left-0 top-0 absolute" src="https://via.placeholder.com/218x205" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Sulawesi
                    Utara</div>
            </div>
            <div class="w-[216px] h-[179px] left-[735px] top-[46px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[293px] h-[430px] left-0 top-0 absolute" src="https://via.placeholder.com/293x430" />
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div> -->
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Bali</div>
            </div>
            <div class="w-[216px] h-[179px] left-[735px] top-[252px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                        src="https://via.placeholder.com/244x172" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Sulawesi
                    Selatan</div>
            </div>
        </div>
        <div class="w-[951px] h-[638px] left-[100px] top-[125px] absolute">
            <div class="left-0 top-0 absolute text-stone-800 text-xl font-medium font-['Poppins']">Semua Provinsi</div>
            <div class="w-[216px] h-[179px] left-0 top-[458px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-[-0px] absolute"
                        src="{{ URL('assets/img/jatim.jpg')}}" />
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Kalimatan
                    Timur</div>
            </div>
            <div class="w-[216px] h-[179px] left-[245px] top-[458px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <!-- <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                        src="https://via.placeholder.com/220x236" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Nusa
                    Tenggara Timur</div>
            </div>
            <div class="w-[216px] h-[180px] left-[490px] top-[458px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[218px] h-[205px] left-0 top-0 absolute" src="https://via.placeholder.com/218x205" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[153px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Maluku
                </div>
            </div>
            <div class="w-[216px] h-[179px] left-[735px] top-[458px] absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                        src="https://via.placeholder.com/244x172" /> -->
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Gorontalo
                </div>
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-0 absolute" src="{{ URL('assets/img/jatim.jpg')}}" />
                </div>
            </div>
        </div>
        <div class="w-[951px] h-[180px] left-[100px] top-[790px] absolute">
            <div class="w-[216px] h-[179px] left-0 top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-[-0px] absolute"
                        src="{{ URL('assets/img/jatim.jpg')}}" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Kalimatan
                    Selatan</div>
            </div>
            <div class="w-[216px] h-[179px] left-[245px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                        src="https://via.placeholder.com/220x236" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Kalimantan
                    Utara</div>
            </div>
            <div class="w-[216px] h-[180px] left-[490px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[218px] h-[205px] left-0 top-0 absolute" src="https://via.placeholder.com/218x205" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[153px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Nusa
                    Tenggara Barat</div>
            </div>
            <div class="w-[216px] h-[179px] left-[735px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                        src="https://via.placeholder.com/244x172" /> -->
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Riau</div>
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-0 absolute" src="{{ URL('assets/img/jatim.jpg')}}" />
                </div>
            </div>
        </div>
        <div class="w-[952px] h-[588px] left-[100px] top-[997px] absolute">
            <div class="w-[216px] h-[179px] left-0 top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-[-0px] absolute"
                        src="{{ URL('assets/img/jatim.jpg')}}" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Papua</div>
            </div>
            <div class="w-[216px] h-[179px] left-[245px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                        src="https://via.placeholder.com/220x236" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Aceh</div>
            </div>
            <div class="w-[216px] h-[180px] left-[490px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[218px] h-[205px] left-0 top-0 absolute" src="https://via.placeholder.com/218x205" /> -->
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="left-0 top-[153px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Banten
                </div>
            </div>
            <div class="w-[216px] h-[179px] left-[735px] top-0 absolute">
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                        src="https://via.placeholder.com/244x172" /> -->
                </div>
                <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Gorontalo
                </div>
                <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                    <img class="w-[216px] h-[140px] left-0 top-0 absolute" src="{{ URL('assets/img/jatim.jpg')}}" />
                </div>
            </div>
            <div class="w-[952px] h-[387px] left-0 top-[201px] absolute">
                <div class="w-[216px] h-[179px] left-0 top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" /> -->
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" />
                        </div>
                    </div>
                    <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                        Kalimatan Timur</div>
                </div>
                <div class="w-[216px] h-[179px] left-[245px] top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                            src="https://via.placeholder.com/220x236" /> -->
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" />
                        </div>
                    </div>
                    <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Nusa
                        Tenggara Timur</div>
                </div>
                <div class="w-[216px] h-[180px] left-[490px] top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[218px] h-[205px] left-0 top-0 absolute"
                            src="https://via.placeholder.com/218x205" /> -->
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" />
                        </div>
                    </div>
                    <div class="left-0 top-[153px] absolute text-stone-800 text-lg font-normal font-['Poppins']">Maluku
                    </div>
                </div>
                <div class="w-[216px] h-[179px] left-[735px] top-0 absolute">
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                            src="https://via.placeholder.com/244x172" /> -->
                    </div>
                    <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                        Gorontalo</div>
                    <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                        <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                            src="{{ URL('assets/img/jatim.jpg')}}" />
                    </div>
                </div>
                <div class="w-[951px] h-[180px] left-[1px] top-[207px] absolute">
                    <div class="w-[216px] h-[179px] left-0 top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" /> -->
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                                <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                                <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                    src="{{ URL('assets/img/jatim.jpg')}}" />
                            </div>
                        </div>
                        <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                            Kalimatan Timur</div>
                    </div>
                    <div class="w-[216px] h-[179px] left-[245px] top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[220px] h-[236px] left-[-4px] top-0 absolute"
                                src="https://via.placeholder.com/220x236" /> -->
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                                <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                                <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                    src="{{ URL('assets/img/jatim.jpg')}}" />
                            </div>
                        </div>
                        <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                            Nusa Tenggara Timur</div>
                    </div>
                    <div class="w-[216px] h-[180px] left-[490px] top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[218px] h-[205px] left-0 top-0 absolute"
                                src="https://via.placeholder.com/218x205" /> -->
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                                <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                                <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                    src="{{ URL('assets/img/jatim.jpg')}}" />
                            </div>
                        </div>
                        <div class="left-0 top-[153px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                            Maluku</div>
                    </div>
                    <div class="w-[216px] h-[179px] left-[735px] top-0 absolute">
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <!-- <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[244px] h-[172px] left-[-2px] top-0 absolute"
                                src="https://via.placeholder.com/244x172" /> -->
                        </div>
                        <div class="left-0 top-[152px] absolute text-stone-800 text-lg font-normal font-['Poppins']">
                            Gorontalo</div>
                        <div class="w-[216px] h-[140px] left-0 top-0 absolute">
                            <div class="w-[216px] h-[140px] left-0 top-0 absolute bg-zinc-100 rounded-lg"></div>
                            <img class="w-[216px] h-[140px] left-0 top-0 absolute"
                                src="{{ URL('assets/img/jatim.jpg')}}" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-[951px] h-[46px] left-[101px] top-[34px] absolute">
            <div class="left-[619px] top-[10px] absolute text-right"><span
                    style="text-stone-800 text-base font-normal font-['Poppins']">Beranda </span><span
                    style="text-red-400 text-base font-normal font-['Poppins']">Provinsi</span><span
                    style="text-stone-800 text-base font-normal font-['Poppins']"> </span></div>
            <div
                class="left-[885px] top-[10px] absolute text-right text-stone-800 text-base font-normal font-['Poppins']">
                Hi, Adaa</div>
            <div class="w-[45px] h-[45px] left-[819px] top-0 absolute">
                
            </div>
            <div
                class="left-0 top-[2px] absolute text-center text-red-950 text-2xl font-normal font-['Jawa Palsu'] tracking-wide">
                BudayaPedia</div>
        </div>
        <div class="w-[86px] h-[0px] left-[806px] top-[70px] absolute border-2 border-red-400"></div>
        <div class="w-[1152px] h-[241px] left-0 top-[1666px] absolute">
        <div class="bg-brown-300 self-stretch flex grow flex-col mt-12 pt-7 pb-10 px-5 max-md:max-w-full max-md:mt-10">
            <div class="self-center flex w-[950px] max-w-full items-start justify-between gap-5 max-md:flex-wrap">
                <div class="flex flex-col">
                    <div class="text-red-950 text-center text-2xl tracking-wider">
                        BudayaPedia
                    </div>
                    <div class="text-red-950 text-xl font-medium mt-5">
                        Jl. Sigura - gura 10,
                        <br />
                        Kel. Sumbersari, Kec. Lowokwaru,
                        <br />
                        Kota Malang
                    </div>
                </div>
                <div class="flex flex-col">
                    <div class="text-red-950 text-center text-xl font-medium">Find us:</div>
                    <div class="flex w-[212px] max-w-full items-start justify-between gap-5 mt-3 max-md:justify-center">
                        <img loading="lazy" srcset="{{ URL('assets\img\icon-twitter.svg') }}"
                            class="aspect-[1.25] object-cover object-center w-full fill-red-950 overflow-hidden flex-1 my-auto" />
                        <img loading="lazy" srcset="{{ URL('assets\img\icon-instagram.svg') }}"
                            class="aspect-[1.25] object-cover object-center w-full fill-red-950 overflow-hidden flex-1 my-auto" />
                        <img loading="lazy" srcset="{{ URL('assets\img\icon-email.svg') }}"
                            class="aspect-[1.25] object-cover object-center w-full fill-red-950 overflow-hidden flex-1 my-auto" />
                        <img loading="lazy" srcset="..."
                            class="aspect-square object-cover object-center w-full overflow-hidden flex-1" />
                    </div>
                </div>
            </div>
            <div class="text-red-950 text-center text-base font-medium self-center mt-6">
                Made with love by ADA
            </div>
        </div>
    </div>
    </div>
</body>

</html>